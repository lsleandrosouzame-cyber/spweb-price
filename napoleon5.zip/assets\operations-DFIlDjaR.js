import{c}from"./index-B1kbMvJW.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const s=c("Scale",[["path",{d:"m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"7g6ntu"}],["path",{d:"m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z",key:"ijws7r"}],["path",{d:"M7 21h10",key:"1b0cd5"}],["path",{d:"M12 3v18",key:"108xh3"}],["path",{d:"M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2",key:"3gwbw2"}]]);/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=c("Wallet",[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]);function h(t,n,e){if(![t,n,e].every(Number.isFinite)||t<0||n<=0||e<=0)throw new RangeError("Despesas devem ser não negativas; dias e horas produtivas devem ser maiores que zero.");const a=n*e;return{fixedMonthlyCents:t,monthlyProductiveHours:a,fixedDailyCents:t/n,fixedHourlyCents:t/a}}function d(t,n){if(!Number.isFinite(t)||t<0||n.length===0)return null;const e=n.reduce((i,r)=>{if(r.quantity<0||r.sellingPriceCents<0||!Number.isFinite(r.contributionCents))throw new RangeError("O mix de vendas contém quantidades ou valores inválidos.");return{revenue:i.revenue+r.sellingPriceCents*r.quantity,contribution:i.contribution+r.contributionCents*r.quantity}},{revenue:0,contribution:0});if(e.revenue<=0)return null;const a=e.contribution/e.revenue*100;if(a<=0)return null;const u=t/(a/100);return{weightedContributionMarginPercent:a,breakEvenRevenueCents:u,referenceRevenueCents:e.revenue,remainingRevenueCents:Math.max(0,u-e.revenue),progressPercent:Math.min(100,e.revenue/u*100)}}export{s as S,v as W,h as a,d as c};
