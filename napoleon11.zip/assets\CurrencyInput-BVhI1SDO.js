import{c as u,j as o}from"./index-C9j9lcHR.js";/**
 * @license lucide-react v0.468.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=u("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);function p({value:a,onChange:e,...r}){function c(t){const n=t.replace(/\D/g,"");if(!n){e("");return}const i=Number(n);Number.isSafeInteger(i)&&e((i/100).toLocaleString("pt-BR",{minimumFractionDigits:2,maximumFractionDigits:2}))}return o.jsx("input",{...r,type:"text",inputMode:"decimal",value:a,onChange:t=>c(t.target.value)})}export{p as C,m as P};
